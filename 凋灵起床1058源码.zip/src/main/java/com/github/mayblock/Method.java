package com.github.mayblock;

import java.lang.reflect.Field;

public class Method {

    public static Object getPrivateField(String name, Class<?> clazz, Object object) {
        Field field;
        Object o = null;
        try {
            field = clazz.getDeclaredField(name);
            field.setAccessible(true);
            o = field.get(object);
        }
        catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
        return o;
    }
}
