package com.github.mayblock.config;

public class SettingConfig extends ConfigManager{

    public SettingConfig cfg;

    public SettingConfig() {
        super("setting", "plugins/BedWarsAddon");
        this.cfg = this;
        this.getYml().options().copyDefaults(true);

        this.getYml().addDefault("wither.name", "{team} {color}凋灵");
        this.getYml().addDefault("wither.max_health", 120);
        this.getYml().addDefault("wither.destroy_own", "&c你不能攻击自己队伍的凋灵！");
        this.getYml().addDefault("wither.kill_message", "&7你击杀了 {team} &7的凋灵！");
        this.save();
    }

    public String getName(){
        return this.getYml().getString("wither.name").replace("&", "§");
    }

    public String getDestroyOwn(){
        return this.getYml().getString("wither.destroy_own").replace("&", "§");
    }

    public int getMaxHealth(){
        return this.getYml().getInt("wither.max_health");
    }

    public String getKillMessage(){
        return this.getYml().getString("wither.kill_message").replace("&", "§");
    }
}
