package com.github.mayblock.api;

import com.andrei1058.bedwars.BedWars;
import com.andrei1058.bedwars.api.arena.IArena;
import com.andrei1058.bedwars.api.arena.team.ITeam;
import com.andrei1058.bedwars.api.configuration.ConfigPath;
import com.andrei1058.bedwars.api.events.player.PlayerBedBreakEvent;
import com.andrei1058.bedwars.api.language.Language;
import com.andrei1058.bedwars.api.language.Messages;
import com.andrei1058.bedwars.configuration.Sounds;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import static com.andrei1058.bedwars.api.language.Language.getMsg;

public class GameManager {

    private IArena arena;

    public GameManager(IArena arena){
        this.arena = arena;
    }

    public IArena getArena() {
        return arena;
    }

    public boolean breakBed(ITeam team, Player breakPlayer) {
        ITeam breakTeam = arena.getTeam(breakPlayer);
        if (breakTeam == null) {
            return false;
        }
        team.setBedDestroyed(true);
        arena.addPlayerBedDestroyed(breakPlayer);
        PlayerBedBreakEvent breakEvent;
        Bukkit.getPluginManager().callEvent(breakEvent = new PlayerBedBreakEvent(breakPlayer, breakTeam, team, arena,
                player -> {
                    if (team.isMember(player)) {
                        return getMsg(player, Messages.INTERACT_BED_DESTROY_CHAT_ANNOUNCEMENT_TO_VICTIM);
                    } else {
                        return getMsg(player, Messages.INTERACT_BED_DESTROY_CHAT_ANNOUNCEMENT);
                    }
                },
                player -> {
                    if (team.isMember(player)) {
                        return getMsg(player, Messages.INTERACT_BED_DESTROY_TITLE_ANNOUNCEMENT);
                    }
                    return null;
                },
                player -> {
                    if (team.isMember(player)) {
                        return getMsg(player, Messages.INTERACT_BED_DESTROY_SUBTITLE_ANNOUNCEMENT);
                    }
                    return null;
                }));
        for (Player arenaPlayer : arena.getPlayers()){
            if (breakEvent.getMessage() != null) {
                arenaPlayer.sendMessage(breakEvent.getMessage().apply(arenaPlayer)
                        .replace("{TeamColor}", team.getColor().chat().toString())
                        .replace("{TeamName}", team.getDisplayName(Language.getPlayerLanguage(arenaPlayer)))
                        .replace("{PlayerColor}", arena.getTeam(breakPlayer).getColor().chat().toString())
                        .replace("{PlayerName}", breakPlayer.getDisplayName()));
            }
            if (breakEvent.getTitle() != null && breakEvent.getSubTitle() != null) {
                BedWars.nms.sendTitle(arenaPlayer, breakEvent.getTitle().apply(arenaPlayer), breakEvent.getSubTitle().apply(arenaPlayer), 0, 25, 0);
            }
            if (team.isMember(arenaPlayer)) Sounds.playSound(ConfigPath.SOUNDS_BED_DESTROY_OWN, arenaPlayer);
            else Sounds.playSound(ConfigPath.SOUNDS_BED_DESTROY, arenaPlayer);
        }
        return true;
    }
}
