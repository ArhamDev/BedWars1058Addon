package com.github.mayblock.listeners;

import com.andrei1058.bedwars.api.arena.IArena;
import com.andrei1058.bedwars.api.arena.team.ITeam;
import com.andrei1058.bedwars.api.events.gameplay.GameEndEvent;
import com.andrei1058.bedwars.api.events.gameplay.TeamAssignEvent;
import com.andrei1058.bedwars.arena.Arena;
import com.github.mayblock.Main;
import com.github.mayblock.api.GameManager;
import com.github.mayblock.entities.CustomWither;
import com.google.common.collect.Lists;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftEntity;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.HashMap;
import java.util.List;

public class GameListeners implements Listener {

    private final List<IArena> arenas = Lists.newArrayList();
    private final HashMap<IArena, List<Entity>> withersValidTeams = new HashMap<>();

    @EventHandler
    public void onEnd(GameEndEvent e) {
        for (Entity entity : e.getArena().getWorld().getEntities()) {
            if (this.withersValidTeams.get(e.getArena()).contains(entity)) {
                entity.remove();
            }
        }
        this.arenas.remove(e.getArena());
        this.withersValidTeams.remove(e.getArena());
    }

    @EventHandler
    public void onDeath(EntityDeathEvent e) {
        net.minecraft.server.v1_8_R3.Entity entity = ((CraftEntity) e.getEntity()).getHandle();
        if (!(entity instanceof CustomWither)) {
            return;
        }
        e.getDrops().clear();
        CustomWither wither = (CustomWither) entity;
        if (wither.getTeam() == null) {
            return;
        }
        for (IArena arena : this.arenas) {
            Player killer = e.getEntity().getKiller();
            ITeam team = arena.getTeam(killer);
            if (team == null) {
                continue;
            }
            killer.sendMessage(Main.getSetting().getKillMessage().replace("{team}", wither.getTeam().getColor().chat() + wither.getTeam().getName() + ChatColor.RESET));
            GameManager manager = new GameManager(arena);
            manager.breakBed(wither.getTeam(), killer);
        }
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        net.minecraft.server.v1_8_R3.Entity entity = ((CraftEntity) e.getEntity()).getHandle();
        if (!(entity instanceof CustomWither)) {
            return;
        }
        if (e.getCause() == EntityDamageEvent.DamageCause.SUFFOCATION) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onDamageByEntity(EntityDamageByEntityEvent e) {
        net.minecraft.server.v1_8_R3.Entity entity = ((CraftEntity) e.getEntity()).getHandle();
        if (!(entity instanceof CustomWither)) {
            return;
        }
        CustomWither wither = (CustomWither) entity;
        Player p;
        if (e.getDamager() instanceof Player) {
            p = (Player) e.getDamager();
        } else if (e.getDamager() instanceof Arrow && ((Arrow) e.getDamager()).getShooter() instanceof Player) {
            p = (Player) ((Arrow) e.getDamager()).getShooter();
        } else {
            e.setCancelled(true);
            return;
        }
        for (IArena arena : this.arenas) {
            ITeam team = wither.getTeam();
            if (team == null) {
                continue;
            }
            if (!this.withersValidTeams.get(arena).contains(wither.getWitherEntity())) {
                return;
            }
            if (e.getEntity().getEntityId() != wither.getWitherEntity().getEntityId()) {
                return;
            }
            if (team.isMember(p)) {
                p.sendMessage(Main.getSetting().getDestroyOwn());
                e.setCancelled(true);
            }
            return;
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onStart(TeamAssignEvent e) {
        if (this.arenas.contains(e.getArena())) {
            return;
        }
        this.arenas.add(e.getArena());
        List<ITeam> teams = e.getArena().getTeams();
        for (ITeam team : teams) {
            Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
                team.getBed().getBlock().setType(Material.AIR);
                if (team.getMembers().size() == 0) {
                    return;
                }
                CustomWither wither = new CustomWither(team);
                wither.spawnWither();
                List<Entity> arenaWithers = this.withersValidTeams.get(e.getArena()) == null ? Lists.newArrayList() : this.withersValidTeams.get(e.getArena());
                arenaWithers.add(wither.getWitherEntity());
                this.withersValidTeams.put(e.getArena(), arenaWithers);
            }, 10L);
        }
    }

    @EventHandler
    public void onTarget(EntityTargetEvent e){
        net.minecraft.server.v1_8_R3.Entity entity = ((CraftEntity) e.getEntity()).getHandle();
        if (!(entity instanceof CustomWither)) {
            return;
        }
        CustomWither wither = (CustomWither) entity;
        if (wither.getTeam() == null) {
            return;
        }
        if (!(e.getTarget() instanceof Player)) {
            e.setCancelled(true);
            return;
        }
        Player p = (Player) e.getTarget();
        for (IArena arena : this.arenas) {
            if (arena.getPlayers().contains(p) && wither.getTeam().isMember(p)){
                e.setCancelled(true);
                break;
            }
        }
    }

    @EventHandler
    public void onPreprocess(PlayerCommandPreprocessEvent e) {
        System.out.println(e.getMessage());
        if (e.getMessage().equalsIgnoreCase("/bwaddon")) {
            e.getPlayer().sendMessage(Main.getPrefix() + ChatColor.RED + " BedWarsAddon - " + Main.getInstance().getDescription().getVersion() + ChatColor.DARK_GRAY + " (By StarrySky)");
            e.setCancelled(true);
        }
    }
}
