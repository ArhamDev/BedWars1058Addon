package com.github.mayblock.entities;

import com.andrei1058.bedwars.api.arena.team.ITeam;
import com.github.mayblock.Main;
import com.github.mayblock.Method;
import net.minecraft.server.v1_8_R3.*;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.util.UnsafeList;
import org.bukkit.entity.Wither;
import org.bukkit.event.entity.CreatureSpawnEvent;

import javax.annotation.Nullable;
import java.lang.reflect.Field;
import java.util.List;

public class CustomWither extends EntityWither {

    private static final int id = 64;
    private ITeam team = null;
    private final Location location;
    private final WorldServer world;
    private final Wither witherEntity;

    public CustomWither(ITeam team){
        super(((CraftWorld) team.getBed().getWorld()).getHandle());
        this.world = ((CraftWorld) team.getBed().getWorld()).getHandle();
        this.location = team.getBed();
        this.team = team;
        List goalB = (List) Method.getPrivateField("b", PathfinderGoalSelector.class, goalSelector); goalB.clear();
        List goalC = (List) Method.getPrivateField("c", PathfinderGoalSelector.class, goalSelector); goalC.clear();
        List targetB = (List) Method.getPrivateField("b", PathfinderGoalSelector.class, targetSelector); targetB.clear();
        List targetC = (List) Method.getPrivateField("c", PathfinderGoalSelector.class, targetSelector); targetC.clear();
        this.witherEntity = (Wither) this.getBukkitEntity();
        this.goalSelector.a(1, new PathfinderGoalLookAtPlayer(this, EntityHuman.class, 8.0F));
        //this.goalSelector.a(2, new PathfinderGoalArrowAttack(this, 0, 0, 0));
        //this.targetSelector.a(2, new PathfinderGoalNearestAttackableTarget<>(this, EntityWither.class, true));
        //this.setHealth(Main.getSetting().getMaxHealth());
        this.setCustomName(Main.getSetting().getName().replace("{team}", team.getColor().chat() + team.getName() + ChatColor.RESET).replace("{color}", team.getColor().chat().toString()));
        this.setCustomNameVisible(true);
        this.b_ = 0; // drop EXP
    }

    public CustomWither(Location loc, String name) {
        super(((CraftWorld) loc.getWorld()).getHandle());
        this.world = ((CraftWorld) loc.getWorld()).getHandle();
        this.location = loc;
        List goalB = (List) Method.getPrivateField("b", PathfinderGoalSelector.class, goalSelector); goalB.clear();
        List goalC = (List) Method.getPrivateField("c", PathfinderGoalSelector.class, goalSelector); goalC.clear();
        List targetB = (List) Method.getPrivateField("b", PathfinderGoalSelector.class, targetSelector); targetB.clear();
        List targetC = (List) Method.getPrivateField("c", PathfinderGoalSelector.class, targetSelector); targetC.clear();
        this.witherEntity = (Wither) this.getBukkitEntity();
        this.goalSelector.a(1, new PathfinderGoalLookAtPlayer(this, EntityHuman.class, 8.0F));
        this.setCustomName(name);
        this.setCustomNameVisible(true);
        this.b_ = 0; // drop EXP
    }

    /* move disabled */
    @Override
    public void move(double d0, double d1, double d2){ }

    @Override
    protected void initAttributes() {
        super.initAttributes();
        this.getAttributeInstance(GenericAttributes.maxHealth).setValue(Main.getSetting().getMaxHealth());
        this.getAttributeInstance(GenericAttributes.MOVEMENT_SPEED).setValue(0);
        this.getAttributeInstance(GenericAttributes.FOLLOW_RANGE).setValue(1.0D);
    }

    @Override
    public WorldServer getWorld() {
        return world;
    }

    @Nullable
    public ITeam getTeam() {
        return team;
    }

    public Wither getWitherEntity() {
        return witherEntity;
    }

    public Location getLocation(){
        return location;
    }

    public void spawnWither() {
        //this.setLocation(location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
        this.setPosition(location.getX(), location.getY(), location.getZ());
        this.getWorld().addEntity(this, CreatureSpawnEvent.SpawnReason.CUSTOM);
    }

    public static void registerWither(){
        EntityManager.registerEntity("Wither", id, EntityWither.class, CustomWither.class);
    }
}

class WitherAI {

}
