package com.github.mayblock;

import com.github.mayblock.commands.Test;
import com.github.mayblock.config.SettingConfig;
import com.github.mayblock.entities.CustomWither;
import com.github.mayblock.listeners.GameListeners;
import com.google.lmachine.BootLoader;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {

    private static Main instance;
    private static SettingConfig setting;
    private static String prefix;

    public static Main getInstance() {
        return instance;
    }

    public static SettingConfig getSetting() {
        return setting;
    }

    public static String getPrefix(){
        return prefix;
    }

    @Override
    public void onLoad() {
        prefix = ChatColor.AQUA + "["+this.getDescription().getPrefix()+"]" + ChatColor.RESET;
        Bukkit.getConsoleSender().sendMessage(prefix + ChatColor.YELLOW + " 插件加载中...");
        setting = new SettingConfig();
        BootLoader.load();
    }

    @Override
    public void onEnable() {
        instance = this;
        if (Bukkit.getPluginManager().getPlugin("BedWars1058") == null){
            Bukkit.getConsoleSender().sendMessage(ChatColor.DARK_RED + "-------------------------------");
            Bukkit.getConsoleSender().sendMessage(prefix + ChatColor.RED + " 插件加载失败！");
            Bukkit.getConsoleSender().sendMessage(prefix + ChatColor.YELLOW + " 未找到前置插件 BedWars1058");
            Bukkit.getConsoleSender().sendMessage(ChatColor.DARK_RED + "-------------------------------");
            Bukkit.getPluginManager().disablePlugin(this);
        }
        CustomWither.registerWither();
        Bukkit.getPluginCommand("test").setExecutor(new Test());
        Bukkit.getPluginManager().registerEvents(new GameListeners(), this);
        BootLoader.enable(this);
        Bukkit.getConsoleSender().sendMessage(ChatColor.GRAY + "-------------------------------");
        Bukkit.getConsoleSender().sendMessage(prefix + ChatColor.GREEN + " 插件加载完毕！");
        Bukkit.getConsoleSender().sendMessage(prefix + ChatColor.YELLOW + " 作者：StarrySky（原MayBlock）");
        Bukkit.getConsoleSender().sendMessage(prefix + ChatColor.RED + " 联系QQ：2606188320");
        Bukkit.getConsoleSender().sendMessage(ChatColor.GRAY + "-------------------------------");
    }

    @Override
    public void onDisable() {
        BootLoader.disable();
        Bukkit.getConsoleSender().sendMessage(prefix + ChatColor.RED + " 插件已卸载！");
    }
}
