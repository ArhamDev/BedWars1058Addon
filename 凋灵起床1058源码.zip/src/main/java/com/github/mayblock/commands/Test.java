package com.github.mayblock.commands;

import com.github.mayblock.Main;
import com.github.mayblock.entities.CustomWither;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Random;

public class Test implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(Main.getPrefix() + ChatColor.RED + " 用法：/test <wither> [args]");
            return false;
        }
        switch (args[0]){
            case "wither":
            case "w":
                if (!(sender instanceof Player)){
                    sender.sendMessage(Main.getPrefix() + ChatColor.RED + " 控制台不能执行该命令！");
                    return false;
                }
                Player p = (Player)sender;
                CustomWither wither = new CustomWither(p.getLocation(), String.valueOf(new Random().nextInt(100)));
                wither.spawnWither();
                p.sendMessage(Main.getPrefix() + ChatColor.GREEN + " Spawn Wither Success!");
                break;
            default:
                sender.sendMessage(Main.getPrefix() + ChatColor.RED + " 未知参数，清输入 /test 获取帮助！");
        }
        return false;
    }
}
